
import torch

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

from sklearn.metrics import confusion_matrix, f1_score, accuracy_score, precision_score, recall_score, roc_auc_score, \
    classification_report, average_precision_score, roc_curve
from sklearn.metrics import precision_recall_curve, auc
from sklearn.preprocessing import StandardScaler, label_binarize

import numpy as np
import sklearn.metrics
from sklearn.metrics import confusion_matrix, f1_score, accuracy_score, precision_score, recall_score, \
    classification_report

import matplotlib.pyplot as plt

import os
import networkx as nx
from sklearn.metrics import classification_report
import csv

def save_cost(training_time, model_parameters, split_seed, root_result_path):
    # 创建存储路径
    seed_folder_path = os.path.join(root_result_path, split_seed)
    if not os.path.exists(seed_folder_path):
        os.makedirs(seed_folder_path)

    # 文件路径
    cost_file_path = os.path.join(seed_folder_path, 'cost.csv')

    # 保存成本信息到CSV
    with open(cost_file_path, 'w', newline='') as cost_csv:
        csv_writer = csv.writer(cost_csv)
        csv_writer.writerow(['Metric', 'Value'])
        csv_writer.writerow(['Training Time (seconds)', training_time])
        csv_writer.writerow(['Number of Parameters', model_parameters])
    print(f'Cost saved to {cost_file_path}')


def save_micro_average_precision_recall_curve(y_true, y_scores, classes, root_csv_file_path):
    num_classes = len(classes)
    plt.figure(figsize=(10, 8))

    # Binarize the true labels
    # y_true_bin = label_binarize(y_true, classes=[0, 1, 2, 3])
    y_true_bin = label_binarize(y_true, classes=[0, 1, 2, 3, 4, 5])

    # Initialize variables for micro-average precision-recall curve
    precision = dict()
    recall = dict()
    average_precision = dict()
    auc_values = []

    for i in range(num_classes):
        precision[i], recall[i], _ = precision_recall_curve(y_true_bin[:, i], y_scores[:, i])
        average_precision[i] = average_precision_score(y_true_bin[:, i], y_scores[:, i])
        auc_prc = auc(recall[i], precision[i])
        auc_values.append(auc_prc)

        # Save precision-recall curve data to one CSV file for each class
        prc_curve_data = list(zip(recall[i], precision[i]))
        prc_curve_filename = os.path.join(root_csv_file_path, f'prc_curve_class_{i}.csv')

        with open(prc_curve_filename, 'w', newline='') as prc_csv:
            csv_writer = csv.writer(prc_csv)
            csv_writer.writerow(['Recall', 'Precision'])
            csv_writer.writerows(prc_curve_data)

    # Micro-average for precision-recall curve
    precision["micro"], recall["micro"], _ = precision_recall_curve(y_true_bin.ravel(), y_scores.ravel())
    average_precision["micro"] = average_precision_score(y_true_bin.ravel(), y_scores.ravel())

    # Save micro-average precision-recall curve data to a separate CSV file
    prc_curve_data_micro = list(zip(recall["micro"], precision["micro"]))
    prc_curve_filename_micro = os.path.join(root_csv_file_path, 'prc_curve_micro_average.csv')

    with open(prc_curve_filename_micro, 'w', newline='') as prc_micro_csv:
        csv_writer_micro = csv.writer(prc_micro_csv)
        csv_writer_micro.writerow(['Recall', 'Precision'])
        csv_writer_micro.writerows(prc_curve_data_micro)

    # Save all AUC values to one CSV file
    auc_values_filename = os.path.join(root_csv_file_path, 'auc_values_precision_recall.csv')
    with open(auc_values_filename, 'w', newline='') as auc_csv:
        csv_writer = csv.writer(auc_csv)
        csv_writer.writerow(['Class', 'AUC'])
        # Write individual AUC values for each class
        for c, auc_val in zip(classes, auc_values):
            csv_writer.writerow([c, auc_val])

        # Write micro-average AUC value
        csv_writer.writerow(['Micro-average', average_precision["micro"]])
    print('aupr-saved')


def save_micro_average_roc_curve(y_true, y_scores, classes, root_csv_file_path):
    num_classes = len(classes)
    plt.figure(figsize=(12, 8))

    # Binarize the true labels
    # y_true_bin = label_binarize(y_true, classes=[0, 1, 2, 3])
    y_true_bin = label_binarize(y_true, classes=[0, 1, 2, 3, 4, 5])

    # Initialize variables for micro-average ROC curve
    all_fpr = []
    all_tpr = []
    auc_values = []

    # For each class
    for i in range(num_classes):
        # ROC curve
        fpr, tpr, _ = roc_curve(y_true_bin[:, i], y_scores[:, i])
        auc_roc = roc_auc_score(y_true_bin[:, i], y_scores[:, i])
        # Collect data for micro-average
        all_fpr.append(fpr)
        all_tpr.append(tpr)
        auc_values.append(auc_roc)

    # Micro-average for ROC curve
    micro_fpr, micro_tpr, _ = roc_curve(y_true_bin.ravel(), y_scores.ravel())
    micro_auc_roc = roc_auc_score(y_true_bin.ravel(), y_scores.ravel())

    # Save all ROC curve data to one CSV file
    roc_curve_data = list(zip(*all_fpr, *all_tpr))
    roc_curve_data.append(micro_fpr)
    roc_curve_data.append(micro_tpr)

    # Save each ROC curve data to separate CSV files
    for i, (fpr, tpr) in enumerate(zip(all_fpr, all_tpr), start=1):
        curve_data = list(zip(fpr, tpr))
        curve_filename = os.path.join(root_csv_file_path, f'roc_curve_class_{i}.csv')

        with open(curve_filename, 'w', newline='') as curve_csv:
            csv_writer = csv.writer(curve_csv)
            csv_writer.writerow(['FPR', 'TPR'])
            csv_writer.writerows(curve_data)

    # Save micro-average ROC curve data to a separate CSV file
    micro_curve_data = list(zip(micro_fpr, micro_tpr))
    micro_curve_filename = os.path.join(root_csv_file_path, 'roc_curve_micro_average.csv')

    with open(micro_curve_filename, 'w', newline='') as micro_curve_csv:
        csv_writer = csv.writer(micro_curve_csv)
        csv_writer.writerow(['Micro FPR', 'Micro TPR'])
        csv_writer.writerows(micro_curve_data)

    # Save all AUC values to one CSV file
    auc_values_filename = os.path.join(root_csv_file_path, 'auc_values.csv')
    with open(auc_values_filename, 'w', newline='') as auc_csv:
        csv_writer = csv.writer(auc_csv)
        csv_writer.writerow(['Class', 'AUC'])
        # Write individual AUC values for each class
        for c, auc_val in zip(classes, auc_values):
            csv_writer.writerow([c, auc_val])

        # Write micro-average AUC value
        csv_writer.writerow(['Micro-average', micro_auc_roc])
    print('roc-saved')


def save_classification_metrics(y_true, y_pred, average_type, type, seed, root_result_path):
    # Calculate F1 score
    f1_score_value = f1_score(y_true, y_pred, average=average_type)
    accuracy_score_value = accuracy_score(y_true, y_pred)

    # Calculate precision
    precision_value = precision_score(y_true, y_pred, average=average_type)

    # Calculate recall
    recall_value = recall_score(y_true, y_pred, average=average_type)

    # Save each metric to separate CSV files
    metrics_data = {
        'F1_Score': f1_score_value,
        'Accuracy_Score': accuracy_score_value,
        'Precision': precision_value,
        'Recall': recall_value
    }

    metrics_filename = os.path.join(root_result_path, f'classification_metrics_{type}_seed_{seed}.csv')

    with open(metrics_filename, 'w', newline='') as metrics_csv:
        csv_writer = csv.writer(metrics_csv)
        csv_writer.writerow(['Metric', 'Value'])
        csv_writer.writerows(metrics_data.items())
    print('metrics-saved')


def convert_multigraph_to_simple(multigraph):
    # Create an empty simple graph
    simple_graph = nx.Graph()

    for u, v, data in multigraph.edges(data=True):
        if simple_graph.has_edge(u, v):
            # Edge already exists, so we take the mean of the 'angle' attribute
            simple_graph[u][v]['angle'] = np.mean([simple_graph[u][v]['angle'], data.get('angle', 0)])
        else:
            # Otherwise, add a new edge with the 'angle' attribute
            simple_graph.add_edge(u, v, angle=data.get('angle', 0))

    return simple_graph


def calculate_metrics0(y_pred, y_true):
    print(f"\nConfusion Matrix:\n{confusion_matrix(y_true, y_pred)}")
    f1 = f1_score(y_true, y_pred, average="weighted")
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average="weighted")
    recall = recall_score(y_true, y_pred, average="weighted")
    print(f"F1 Score: {f1}")
    print(f"Accuracy: {accuracy}")
    print(f"Precision: {precision}")
    print(f"Recall: {recall}")
    print(classification_report(y_true, y_pred))

def calculate_metrics(y_pred, y_true, all_scores=None, save_results=False, split_seed=None, dataset_type=None,
                      root_result_path=None):
    # 计算整体的宏观指标
    average_type = "weighted"
    print(f"\nConfusion Matrix:\n{confusion_matrix(y_true, y_pred)}")
    f1 = f1_score(y_true, y_pred, average="weighted")
    accuracy = accuracy_score(y_true, y_pred)  # 计算整体准确率
    precision = precision_score(y_true, y_pred, average="weighted")
    recall = recall_score(y_true, y_pred, average="weighted")
    print(f"F1 Score: {f1}")
    print(f"Accuracy: {accuracy}")
    print(f"Precision: {precision}")
    print(f"Recall: {recall}")

    # 输出每个类别的详细分类报告
    class_report = classification_report(y_true, y_pred, output_dict=True)
    print(classification_report(y_true, y_pred))  # 打印到控制台

    # 计算每个类别的准确率（类的准确率 = 类别正确预测数 / 类别总数）
    accuracy_per_class = {}
    for class_label in class_report:
        if class_label not in ['accuracy', 'macro avg', 'weighted avg']:
            true_positives = confusion_matrix(y_true, y_pred)[int(class_label), int(class_label)]
            class_samples = list(y_true).count(int(class_label))
            accuracy_per_class[class_label] = true_positives / class_samples if class_samples > 0 else 0

    print(f"Accuracy per class: {accuracy_per_class}")

    # 保存每个类别的详细指标到文件
    if save_results:
        # 创建保存路径
        seed_folder_path = os.path.join(root_result_path, split_seed)
        if not os.path.exists(seed_folder_path):
            os.makedirs(seed_folder_path)
        datasettype_seed_folder_path = os.path.join(seed_folder_path, dataset_type)
        if not os.path.exists(datasettype_seed_folder_path):
            os.makedirs(datasettype_seed_folder_path)

        # 保存分类报告到CSV文件
        report_filename = os.path.join(datasettype_seed_folder_path, 'classification_report.csv')
        with open(report_filename, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Class', 'Precision', 'Recall', 'F1-Score', 'Support', 'Accuracy'])  # 新增 Accuracy 列
            for class_label, metrics in class_report.items():
                if class_label not in ['accuracy', 'macro avg', 'weighted avg']:
                    writer.writerow(
                        [class_label] + [metrics.get(x) for x in ['precision', 'recall', 'f1-score', 'support']] + [
                            accuracy_per_class.get(class_label, 0)])

        # 保存微平均和宏平均（AUC）等
        save_micro_average_roc_curve(y_true, all_scores, ['0', '1', '2', '3', '4', '5'], datasettype_seed_folder_path)
        save_micro_average_precision_recall_curve(y_true, all_scores, ['0', '1', '2', '3', '4', '5'],
                                                  datasettype_seed_folder_path)
        save_classification_metrics(y_true, y_pred, average_type, dataset_type, split_seed,
                                    datasettype_seed_folder_path)
        print('save all result done')