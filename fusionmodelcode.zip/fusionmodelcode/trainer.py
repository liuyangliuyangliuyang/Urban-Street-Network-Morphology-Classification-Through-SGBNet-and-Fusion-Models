
import torch
import utils
import numpy as np
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def train(model, train_loader, optimizers, criterion, device):
    global combined_features_storage
    combined_features_storage = []  # Clear previous features

    model.train()
    total_loss = 0
    all_preds = []
    all_labels = []
    all_indices = []  # To store indices

    for data, indices in train_loader:

        # Move data to device and prepare inputs
        for key in data.keys():
            if isinstance(data[key], torch.Tensor):
                data[key] = data[key].to(device)

        # Clear gradients for all optimizers
        for opt in optimizers.values():
            opt.zero_grad()

        if 'cnn' in data:
            data['cnn'] = data['cnn'].to(device)
        if 'gnn0' in data:
            data['gnn0'].x = data['gnn0'].x.to(device)
            data['gnn0'].edge_index = data['gnn0'].edge_index.to(device)
            data['gnn0'].edge_attr = data['gnn0'].edge_attr.to(device)
            data['gnn0'].batch = data['gnn0'].batch.to(device) if hasattr(data['gnn0'], 'batch') else None
        if 'gnn1' in data:
            data['gnn1'].x = data['gnn1'].x.to(device)
            data['gnn1'].edge_index = data['gnn1'].edge_index.to(device)
            data['gnn1'].edge_attr = data['gnn1'].edge_attr.to(device)
            data['gnn1'].batch = data['gnn1'].batch.to(device) if hasattr(data['gnn1'], 'batch') else None
        if 'gnn2' in data:
            data['gnn2'].x = data['gnn2'].x.to(device)
            data['gnn2'].edge_index = data['gnn2'].edge_index.to(device)
            data['gnn2'].edge_attr = data['gnn2'].edge_attr.to(device)
            data['gnn2'].batch = data['gnn2'].batch.to(device) if hasattr(data['gnn2'], 'batch') else None
        if 'global' in data:
            data['global'] = data['global'].to(device)
        if 'global0' in data:
            data['global0'] = data['global0'].to(device)


        # Compute the model output
        output = model(data)
        loss = criterion(output, data['label'].view(-1))  # Assuming 'label' is always present
        total_loss += loss.item()

        # Perform backpropagation
        loss.backward()

        # Step each optimizer
        for opt in optimizers.values():
            opt.step()

        # Optionally accumulate predictions and labels for further analysis
        _, preds = output.max(1)
        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(data['label'].cpu().numpy())
        all_indices.extend(indices)

    utils.calculate_metrics(np.array(all_preds), np.array(all_labels))

    return total_loss / len(train_loader), all_indices


def evaluate(model, loader, criterion, device):
    global combined_features_storage
    combined_features_storage = []  # Clear previous features

    model.eval()
    total_loss = 0
    all_preds = []
    all_labels = []
    all_indices = []  # To store indices

    with torch.no_grad():
        for data, indices in loader:
            # Move data to device
            for key in data.keys():
                if isinstance(data[key], torch.Tensor):
                    data[key] = data[key].to(device)

            if 'cnn' in data:
                data['cnn'] = data['cnn'].to(device)
            if 'gnn0' in data:
                data['gnn0'].x = data['gnn0'].x.to(device)
                data['gnn0'].edge_index = data['gnn0'].edge_index.to(device)
                data['gnn0'].edge_attr = data['gnn0'].edge_attr.to(device)
                data['gnn0'].batch = data['gnn0'].batch.to(device) if hasattr(data['gnn0'], 'batch') else None
            if 'gnn1' in data:
                data['gnn1'].x = data['gnn1'].x.to(device)
                data['gnn1'].edge_index = data['gnn1'].edge_index.to(device)
                data['gnn1'].edge_attr = data['gnn1'].edge_attr.to(device)
                data['gnn1'].batch = data['gnn1'].batch.to(device) if hasattr(data['gnn1'], 'batch') else None
            if 'gnn2' in data:
                data['gnn2'].x = data['gnn2'].x.to(device)
                data['gnn2'].edge_index = data['gnn2'].edge_index.to(device)
                data['gnn2'].edge_attr = data['gnn2'].edge_attr.to(device)
                data['gnn2'].batch = data['gnn2'].batch.to(device) if hasattr(data['gnn2'], 'batch') else None
            if 'global' in data:
                data['global'] = data['global'].to(device)
            if 'global0' in data:
                data['global0'] = data['global0'].to(device)

            # Compute the model output
            output = model(data)
            loss = criterion(output, data['label'].view(-1))  # Assuming 'label' is always present
            total_loss += loss.item()

            # Optionally accumulate predictions and labels for further analysis
            _, preds = output.max(1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(data['label'].cpu().numpy())
            all_indices.extend(indices)

    average_loss = total_loss / len(loader)
    utils.calculate_metrics(np.array(all_preds), np.array(all_labels))
    return average_loss, all_indices


def evaluate1(model, loader, criterion, device,save_results=False,split_seed = None,dataset_type = None,root_result_path=None):
    global combined_features_storage
    combined_features_storage = []  # Clear previous features

    model.eval()
    total_loss = 0
    all_preds = []
    all_scores = []
    all_labels = []
    all_indices = []  # To store indices

    with torch.no_grad():
        for data, indices in loader:
            # Move data to device
            for key in data.keys():
                if isinstance(data[key], torch.Tensor):
                    data[key] = data[key].to(device)

            if 'cnn' in data:
                data['cnn'] = data['cnn'].to(device)
            if 'gnn0' in data:
                data['gnn0'].x = data['gnn0'].x.to(device)
                data['gnn0'].edge_index = data['gnn0'].edge_index.to(device)
                data['gnn0'].edge_attr = data['gnn0'].edge_attr.to(device)
                data['gnn0'].batch = data['gnn0'].batch.to(device) if hasattr(data['gnn0'], 'batch') else None
            if 'gnn1' in data:
                data['gnn1'].x = data['gnn1'].x.to(device)
                data['gnn1'].edge_index = data['gnn1'].edge_index.to(device)
                data['gnn1'].edge_attr = data['gnn1'].edge_attr.to(device)
                data['gnn1'].batch = data['gnn1'].batch.to(device) if hasattr(data['gnn1'], 'batch') else None
            if 'gnn2' in data:
                data['gnn2'].x = data['gnn2'].x.to(device)
                data['gnn2'].edge_index = data['gnn2'].edge_index.to(device)
                data['gnn2'].edge_attr = data['gnn2'].edge_attr.to(device)
                data['gnn2'].batch = data['gnn2'].batch.to(device) if hasattr(data['gnn2'], 'batch') else None
            if 'global' in data:
                data['global'] = data['global'].to(device)
            if 'global0' in data:
                data['global0'] = data['global0'].to(device)

            # Compute the model output
            output = model(data)
            loss = criterion(output, data['label'].view(-1))  # Assuming 'label' is always present
            total_loss += loss.item()

            # Optionally accumulate predictions and labels for further analysis
            _, preds = output.max(1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(data['label'].cpu().numpy())
            pred1 = torch.softmax(output, 1)
            all_scores.extend(pred1.cpu().numpy())
            all_indices.extend(indices)

    average_loss = total_loss / len(loader)
    # calculate_metrics(np.array(all_preds), np.array(all_labels))

    utils.calculate_metrics(np.array(all_preds), np.array(all_labels), np.array(all_scores), save_results, split_seed,
                      dataset_type, root_result_path)
    return average_loss
