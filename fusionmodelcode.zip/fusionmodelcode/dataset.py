import pickle

import h5py
import numpy as np
import torch
from torch.utils.data import Dataset
from torch_geometric.data import Data
import networkx as nx
import torch
from torchvision.transforms import ToTensor

from torch.utils.data import Dataset, DataLoader

from utils import convert_multigraph_to_simple


class DataSource:
    def __init__(self, file_path, data_type, columns, label_column='label0'):
        self.file = h5py.File(file_path, 'r+')
        self.data_type = data_type
        self.columns = columns
        self.label_column = label_column  # Optional, for integrating labels with graph data

    def load_data(self, idx):
        if self.data_type == 'image':
            return self.load_image(idx)
        elif self.data_type == 'graph0':
            return self.load_graph0(idx)
        elif self.data_type == 'graph1':
            return self.load_graph1(idx)
        elif self.data_type == 'graph2':
            return self.load_graph2(idx)
        elif self.data_type == 'global':
            return self.load_global_features(idx)
        elif self.data_type == 'global0':
            return self.load_global_features(idx)
        elif self.data_type == 'label':
            return self.load_labels(idx)
        else:
            raise ValueError(f"Unsupported data type: {self.data_type}")

    def load_image(self, idx):
        # Assuming images are stored in HWC format and need to be converted to CHW for PyTorch
        image_data = torch.tensor(self.file['images'][idx], dtype=torch.float)
        image_data = image_data.permute(2, 0, 1)  # Permute from HWC to CHW
        return image_data / 255.0  # Normalize to [0, 1]

    def load_graph0(self, idx):
        graphs = []
        label = self.load_labels(idx) if self.label_column else None
        for column in self.columns:
            graph_data = pickle.loads(self.file[column][idx].tobytes())
            node_features, edge_index, edge_attr = self.process_graph0(graph_data)
            # Include the label in the graph data if present
            graph_obj = Data(x=node_features, edge_index=edge_index, edge_attr=edge_attr, y=label)
            graphs.append(graph_obj)
        return graphs

    def load_graph1(self, idx):
        graphs = []
        label = self.load_labels(idx) if self.label_column else None
        for column in self.columns:
            graph_data = pickle.loads(self.file[column][idx].tobytes())
            node_features, edge_index, edge_attr = self.process_graph1(graph_data)
            # Include the label in the graph data if present
            graph_obj = Data(x=node_features, edge_index=edge_index, edge_attr=edge_attr, y=label)
            graphs.append(graph_obj)
        return graphs

    def load_graph2(self,idx):
        graphs = []
        label = self.load_labels(idx) if self.label_column else None
        for column in self.columns:
            graph_data = pickle.loads(self.file[column][idx].tobytes())
            node_features, edge_index, edge_attr = self.process_graph2(graph_data)
            # Include the label in the graph data if present
            graph_obj = Data(x=node_features, edge_index=edge_index, edge_attr=edge_attr, y=label)
            graphs.append(graph_obj)
        return graphs

    def process_graph0(self, G):
        # Convert G to node features, edge index, and edge attributes
        node_feats = self._get_node_features0(G)
        edge_feats = self._get_edge_features0(G)
        edge_index = self._get_adjacency_info0(G)

        return node_feats, edge_index, edge_feats

    def process_graph1(self, G):
        # Convert G to node features, edge index, and edge attributes
        node_feats = self._get_node_features1(G)
        edge_feats = self._get_edge_features1(G)
        edge_index = self._get_adjacency_info1(G)

        return node_feats, edge_index, edge_feats

    def process_graph2(self, G):
        # Convert G to node features, edge index, and edge attributes
        node_feats = self._get_node_features2(G)
        edge_feats = self._get_edge_features2(G)
        edge_index = self._get_adjacency_info2(G)

        return node_feats, edge_index, edge_feats
    def load_labels(self, idx):
        # Labels are loaded only if a label column has been specified
        if self.label_column:
            label = torch.tensor(self.file[self.label_column][idx], dtype=torch.long)
            return label
        return None

    @staticmethod
    def _get_node_features0(G):
        all_node_feats = []
        feature_keys = ['area', 'circuity', 'concavity', 'number_of_linestrings', 'formfacter', 'rectanglarity',
                        'elongation', 'degree']
        for node in G.nodes():
            node_feats = []
            for key in feature_keys:
                if key == 'area':  # Scale 'area' feature by dividing by 10000
                    area_value = G.nodes[node].get(key, 0) / 10000
                    node_feats.append(area_value)
                else:
                    node_feats.append(G.nodes[node].get(key, 0))
            all_node_feats.append(node_feats)
        return torch.tensor(all_node_feats, dtype=torch.float)

    @staticmethod
    def _get_node_features1(G):
        all_node_feats = []
        feature_keys = ['circuity', 'sinuosity', 'degree', 'type']
        for node in G.nodes():
            node_feats = []
            for key in feature_keys:
                node_feats.append(G.nodes[node].get(key, 0))
            all_node_feats.append(node_feats)
        return torch.tensor(all_node_feats, dtype=torch.float)

    @staticmethod
    def _get_node_features2(G):
        all_node_feats = []
        feature_keys = ['degree','betweenness_centrality', 'closeness_centrality', 'clustering', 'pagerank']
        for node in G.nodes():
            node_feats = []
            for key in feature_keys:
                node_feats.append(G.nodes[node].get(key, 0))
            all_node_feats.append(node_feats)
        return torch.tensor(all_node_feats, dtype=torch.float)

    @staticmethod
    def _get_edge_features0(G):
        all_edge_feats = []
        for edge in G.edges():
            edge_feats = []
            # Original logic for 'nx_list'
            edge_feats.append(0)  # Placeholder; adjust as needed
            edge_feats.append(0)  # Placeholder; adjust as needed
            all_edge_feats += [edge_feats, edge_feats]  # Consider if duplication is needed based on graph structure
        all_edge_feats = np.asarray(all_edge_feats)
        # print(all_edge_feats.shape)
        return torch.tensor(all_edge_feats, dtype=torch.float)

    @staticmethod
    def _get_edge_features1(G):
        all_edge_feats = []
        for edge in G.edges():
            edge_feats = []
            # Append 'angle' to edge features
            angle = G.edges[edge[0], edge[1], 0]["angle"]
            edge_feats.append(angle)
            # edge_feats.append(angle_value)
            all_edge_feats += [edge_feats, edge_feats]  # Consider if duplication is needed based on graph structure
        all_edge_feats = np.asarray(all_edge_feats)
        # print(all_edge_feats.shape)
        return torch.tensor(all_edge_feats, dtype=torch.float)

    @staticmethod
    def _get_edge_features2(G):
        all_edge_feats = []
        for edge in G.edges():
            edge_feats = []
            # Original logic for 'nx_list'
            edge_feats.append(0)  # Placeholder; adjust as needed
            edge_feats.append(0)  # Placeholder; adjust as needed
            all_edge_feats += [edge_feats, edge_feats]  # Consider if duplication is needed based on graph structure
        all_edge_feats = np.asarray(all_edge_feats)
        # print(all_edge_feats.shape)
        return torch.tensor(all_edge_feats, dtype=torch.float)

    @staticmethod
    def _get_adjacency_info0(G):
        """
        We could also use rdmolops.GetAdjacencyMatrix(mol)
        but we want to be sure that the order of the indices
        matches the order of the edge features
        """
        G = nx.convert_node_labels_to_integers(G)
        G = G.to_directed() if not nx.is_directed(G) else G
        if isinstance(G, (nx.MultiGraph, nx.MultiDiGraph)):
            edges = list(G.edges(keys=False))
        else:
            edges = list(G.edges)
        edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
        # print(edge_index.shape)
        return edge_index

    @staticmethod
    def _get_adjacency_info1(G):
        G = nx.convert_node_labels_to_integers(G)
        # If the graph is a MultiGraph, convert it to a simple graph
        if isinstance(G, nx.MultiGraph):
            G = convert_multigraph_to_simple(G)
        # For an undirected graph, make sure to add both directions for each edge
        edges = []
        if not G.is_directed():
            for u, v in G.edges():
                edges.append((u, v))
                edges.append((v, u))
        else:
            edges = list(G.edges)

        edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
        return edge_index

    @staticmethod
    def _get_adjacency_info2(G):
        G = nx.convert_node_labels_to_integers(G)
        # If the graph is a MultiGraph, convert it to a simple graph
        if isinstance(G, nx.MultiGraph):
            G = convert_multigraph_to_simple(G)
        # For an undirected graph, make sure to add both directions for each edge
        edges = []
        if not G.is_directed():
            for u, v in G.edges():
                edges.append((u, v))
                edges.append((v, u))
        else:
            edges = list(G.edges)

        edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
        return edge_index

    def load_global_features(self, idx):
        # Combine global features from specified columns
        features = np.hstack([self.file[column][idx] for column in self.columns])
        return torch.tensor(features, dtype=torch.float)

    def close(self):
        self.file.close()


class CombinedDataset(Dataset):
    def __init__(self, file_path, config):
        """
        config is a dict specifying the data sources and their types, e.g.,
        {
            'cnn': {'type': 'image', 'columns': ['default']},
            'gnn': {'type': 'graph', 'columns': ['nx_list', 'dual_graph_nx_list']},
            'global': {'type': 'global', 'columns': ['features', 'hand_crafted']}
        }
        """
        self.data_sources = {}
        for key, source_config in config.items():
            self.data_sources[key] = DataSource(file_path, source_config['type'], source_config['columns'])

    def __len__(self):
        first_source = next(iter(self.data_sources.values()))
        # This assumes all data types are aligned and have the same length
        return len(first_source.file[first_source.columns[0]])

    def __getitem__(self, idx):
        data = {}
        for key, source in self.data_sources.items():
            data[key] = source.load_data(idx)
        # Unpack single-item lists for convenience
        for key in data:
            if isinstance(data[key], list) and len(data[key]) == 1:
                data[key] = data[key][0]
        return data

    def close(self):
        for source in self.data_sources.values():
            source.close()


class IndexedDataset0(Dataset):
    """Dataset wrapper to return the index of the item along with the data."""

    def __init__(self, dataset):
        self.dataset = dataset

    def __getitem__(self, index):
        data = self.dataset[index]
        return data, index

    def __len__(self):
        return len(self.dataset)


class IndexedDataset(Dataset):
    """Dataset wrapper to return the index of the item along with the data."""

    def __init__(self, dataset, original_indices):
        self.dataset = dataset
        self.original_indices = original_indices

    def __getitem__(self, index):
        data = self.dataset[index]
        original_index = self.original_indices[index]
        return data, original_index

    def __len__(self):
        return len(self.dataset)

def load_splits_from_h5py(h5_file_path, key):
    """
    Load and deserialize dataset splits from an h5py file.

    Parameters:
    - h5_file_path: Path to the h5py file.
    - key: The key under which the splits are stored.

    Returns:
    - splits: A list of dictionaries with keys 'train', 'validation', and 'test', each containing the corresponding indices.
    """
    with h5py.File(h5_file_path, 'r+') as h5_file:
        if key in h5_file:
            serialized_splits = h5_file[key][()]
            splits = pickle.loads(serialized_splits.tostring())
            return splits
        else:
            print(f"No splits found under the key '{key}'.")
            return None



def generate_datasets_for_split0(dataset, split):
    """
    Generate train, validation, and test datasets based on a single split.

    Parameters:
    - dataset: The original full dataset instance.
    - split: A dictionary with keys 'train', 'validation', and 'test' containing indices.

    Returns:
    - A tuple containing train, validation, and test dataset instances.
    """
    train_indices = split['train']
    val_indices = split['validation']
    test_indices = split['test']

    # Assuming CombinedDataset can be indexed by a list of indices
    train_dataset = torch.utils.data.Subset(dataset, train_indices)
    val_dataset = torch.utils.data.Subset(dataset, val_indices)
    test_dataset = torch.utils.data.Subset(dataset, test_indices)
    # print(test_dataset[0])
    # print(test_dataset[0]['gnn0'].x)
    # print(type(test_dataset[0]))
    # print(len(test_dataset[0]))
    # exit()
    return train_dataset, val_dataset, test_dataset


def generate_datasets_for_split1(dataset, split):
    train_indices = split['train']
    val_indices = split['validation']
    test_indices = split['test']

    train_dataset = IndexedDataset(torch.utils.data.Subset(dataset, train_indices))
    val_dataset = IndexedDataset(torch.utils.data.Subset(dataset, val_indices))
    test_dataset = IndexedDataset(torch.utils.data.Subset(dataset, test_indices))

    return train_dataset, val_dataset, test_dataset


def generate_datasets_for_split(dataset, split):
    train_indices = split['train']
    val_indices = split['validation']
    test_indices = split['test']

    # Assuming CombinedDataset can be indexed by a list of indices
    train_dataset = torch.utils.data.Subset(dataset, train_indices)
    val_dataset = torch.utils.data.Subset(dataset, val_indices)
    test_dataset = torch.utils.data.Subset(dataset, test_indices)

    return IndexedDataset(train_dataset, train_indices), IndexedDataset(val_dataset, val_indices), IndexedDataset(
        test_dataset, test_indices)
