

import os
import time
import torch
from torch_geometric.data import DataLoader
from torch.utils.data import Dataset, DataLoader
import numpy as np
from itertools import combinations
from config import possible_models
from dataset import CombinedDataset, load_splits_from_h5py,generate_datasets_for_split0
from dataset import IndexedDataset
from data_loader import collate_data
from feature_processing import transform_node_features, transform_node_features1,transform_node_features2,transform_features
from trainer import train, evaluate, evaluate1
from models import DynamicModel
from utils import save_cost

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def main():
    # `all_configs` 中
    all_configs = []

    #
    preferred_model_combination = {
        'cnn': possible_models['cnn'],
        'gnn0': possible_models['gnn0'],
        'global0': possible_models['global0'],
        'label': possible_models['label']
    }

    # #
    # preferred_model_combination = {
    #
    #     'gnn0': possible_models['gnn0'],
    #
    #     'label': possible_models['label']
    # }
    # cnn + gnn0 + global0
    all_configs.append(preferred_model_combination)

    # add other combinations
    for key in ['cnn', 'gnn0', 'gnn1', 'gnn2', 'global0']:
        all_configs.append({key: possible_models[key], 'label': possible_models['label']})

    for model1, model2 in combinations(['cnn', 'gnn0', 'gnn1', 'gnn2', 'global0'], 2):
        if 'gnn' in model1 and 'gnn' in model2:
            continue  #
        all_configs.append(
            {model1: possible_models[model1], model2: possible_models[model2], 'label': possible_models['label']})

    #
    for model1, model2, model3 in combinations(['cnn', 'gnn0', 'gnn1', 'gnn2', 'global0'], 3):
        if sum('gnn' in model for model in [model1, model2, model3]) > 1:
            continue  #
        all_configs.append({
            model1: possible_models[model1],
            model2: possible_models[model2],
            model3: possible_models[model3],
            'label': possible_models['label']
        })

    num_classes = 6
    file_path = "C:/urban-street-network-dataset-ALL-IN-ONE.h5"
    # root_result_path_base = "C:/Users/11156/Desktop/gnn-project-main/result-model-performance-revisedrealround1/"
    root_result_path_base = "C:/Users/11156/Desktop/gnn-project-main/feature importance-revisedrealround1/"

    criterion = torch.nn.CrossEntropyLoss()
    all_splits = load_splits_from_h5py(file_path, 'splits_train_ratio_0.6')
    splits_to_use = all_splits[:5]  # only first 5 split

    for config in all_configs:
        #
        model_combination_name = '+'.join([key for key in config if key != 'label'])
        root_result_path = os.path.join(root_result_path_base, model_combination_name)

        if not os.path.exists(root_result_path):
            os.makedirs(root_result_path)

        dataset = CombinedDataset(file_path, config)
        print(f'dataset creation done for combination: {model_combination_name}')

        # each split
        for i, split in enumerate(splits_to_use):
            print(f'starting split seed: {i} for combination: {model_combination_name}')

            start_time = time.time()

            train_dataset, val_dataset, test_dataset = generate_datasets_for_split0(dataset, split)

            if 'gnn0' in config:
                train_dataset, val_dataset, test_dataset = transform_node_features(train_dataset, val_dataset,
                                                                                   test_dataset)
            elif 'gnn1' in config:
                train_dataset, val_dataset, test_dataset = transform_node_features1(train_dataset, val_dataset,
                                                                                    test_dataset)
            elif 'gnn2' in config:
                train_dataset, val_dataset, test_dataset = transform_node_features2(train_dataset, val_dataset,
                                                                                    test_dataset)

            if 'global0' in config:
                train_dataset, val_dataset, test_dataset = transform_features(train_dataset, val_dataset, test_dataset)

            train_loader = DataLoader(IndexedDataset(train_dataset, split['train']), batch_size=32, shuffle=True,
                                      collate_fn=collate_data)
            val_loader = DataLoader(IndexedDataset(val_dataset, split['validation']), batch_size=32, shuffle=False,
                                    collate_fn=collate_data)
            test_loader = DataLoader(IndexedDataset(test_dataset, split['test']), batch_size=32, shuffle=False,
                                     collate_fn=collate_data)

            #
            combined_model = DynamicModel(config, num_classes).to(device)
            print('dynamic model construction done')

            optimizers = {}
            if 'cnn' in config:
                optimizers['cnn'] = torch.optim.SGD(combined_model.get_cnn_parameters(), lr=0.001, momentum=0.9)
            if 'gnn0' in config:
                optimizers['gnn0'] = torch.optim.SGD(combined_model.get_gnn0_parameters(), lr=0.01, momentum=0.9)
            if 'gnn1' in config:
                optimizers['gnn1'] = torch.optim.SGD(combined_model.get_gnn1_parameters(), lr=0.01, momentum=0.9)
            if 'gnn2' in config:
                optimizers['gnn2'] = torch.optim.SGD(combined_model.get_gnn2_parameters(), lr=0.01, momentum=0.9)
            if 'global0' in config:
                optimizers['global0'] = torch.optim.Adam(combined_model.models['global0'].parameters(), lr=0.001)

            best_val_loss = float('inf')
            early_stopping_patience = 2
            early_stopping_counter = 0
            best_model_path = 'best_model.pth'

            for epoch in range(1, 30):
                print(f"Epoch {epoch} for combination: {model_combination_name}")
                #
                train_loss, train_indices = train(combined_model, train_loader, optimizers, criterion, device)

                #
                val_loss, val_indices = evaluate(combined_model, val_loader, criterion, device)
                print(f"Validation Loss: {val_loss}")

                #
                test_loss, test_indices = evaluate(combined_model, test_loader, criterion, device)
                print(f"Epoch {epoch}, Test Loss: {test_loss}")

                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    torch.save(combined_model.state_dict(), best_model_path)
                    print("Best model updated")
                    early_stopping_counter = 0
                else:
                    early_stopping_counter += 1
                    if early_stopping_counter >= early_stopping_patience:
                        print("Early stopping triggered.")
                        break

            # best model
            combined_model.load_state_dict(torch.load(best_model_path))
            final_test_loss = evaluate1(combined_model, test_loader, criterion, device, save_results=True,
                                        split_seed=str(i),
                                        dataset_type='test', root_result_path=root_result_path)
            print(f"Final Test Loss: {final_test_loss}")

            final_test_loss = evaluate1(combined_model, val_loader, criterion, device, save_results=True,
                                        split_seed=str(i),
                                        dataset_type='val', root_result_path=root_result_path)
            final_test_loss = evaluate1(combined_model, train_loader, criterion, device, save_results=True,
                                        split_seed=str(i),
                                        dataset_type='train', root_result_path=root_result_path)

            #
            save_cost(time.time() - start_time, sum(p.numel() for p in combined_model.parameters()), str(i),
                      root_result_path)

            print(f"best Test Loss: {test_loss}")
            print(f'finish split seed: {i} for combination: {model_combination_name}')

    print('All combinations completed')



if __name__ == "__main__":
    main()
