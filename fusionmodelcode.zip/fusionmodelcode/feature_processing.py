import numpy as np
import torch
from matplotlib import pyplot as plt
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from torch_geometric.data import Batch
import networkx as nx
from torch_geometric.utils import to_networkx



def extract_global_features0(dataset):
    """ Extract the 'global0' feature from each sample in the dataset. """
    return torch.stack([x['global0'] for x in dataset])

def extract_global_features(dataset):
    """ Extract the 'global0' feature from each sample in the dataset. """
    return torch.stack([x[0]['global0'] for x in dataset])
def replace_global_features(dataset, transformed_features):
    """ Replace the 'global0' feature in the original dataset with the transformed features. """
    for (sample, _), new_feature in zip(dataset, transformed_features):
        sample['global0'] = new_feature
    return dataset


def replace_global_features0(dataset, transformed_features):
    """ Replace the 'global0' feature in the original dataset with the transformed features. """
    for sample, new_feature in zip(dataset, transformed_features):
        sample['global0'] = new_feature
    return dataset


def transform_features(train_dataset, val_dataset, test_dataset):
    # Convert PyTorch datasets to lists for easier manipulation
    train_list = [train_dataset[i] for i in range(len(train_dataset))]
    val_list = [val_dataset[i] for i in range(len(val_dataset))]
    test_list = [test_dataset[i]for i in range(len(test_dataset))]

    # Convert PyTorch datasets to lists for easier manipulation
    # train_list = [train_dataset[i][0] for i in range(len(train_dataset))]  # Unpack the data part
    # val_list = [val_dataset[i][0] for i in range(len(val_dataset))]
    # test_list = [test_dataset[i][0] for i in range(len(test_dataset))]

    # Extract global features from each dataset
    X_train = extract_global_features0(train_list)
    X_val = extract_global_features0(val_list)
    X_test = extract_global_features0(test_list)

    # Convert tensors to numpy for scaling
    X_train_np = X_train.numpy()
    X_val_np = X_val.numpy()
    X_test_np = X_test.numpy()

    # Initialize scalers
    scaler_min_max = MinMaxScaler()
    scaler_standard = StandardScaler()

    # Fit and transform training data
    X_train_np = scaler_min_max.fit_transform(X_train_np)
    X_train_np = scaler_standard.fit_transform(X_train_np)

    # Transform validation and test data using the fitted scalers
    X_val_np = scaler_min_max.transform(X_val_np)
    X_val_np = scaler_standard.transform(X_val_np)
    X_test_np = scaler_min_max.transform(X_test_np)
    X_test_np = scaler_standard.transform(X_test_np)

    # Convert numpy arrays back to tensors
    X_train_torch = torch.tensor(X_train_np, dtype=torch.float32)
    X_val_torch = torch.tensor(X_val_np, dtype=torch.float32)
    X_test_torch = torch.tensor(X_test_np, dtype=torch.float32)

    # Replace the original global0 features with transformed features
    train_dataset = replace_global_features0(train_list, X_train_torch)
    val_dataset = replace_global_features0(val_list, X_val_torch)
    test_dataset = replace_global_features0(test_list, X_test_torch)

    return train_dataset, val_dataset, test_dataset


def extract_node_features(dataset):
    """ Extract the node features (x) from each graph in the dataset. """
    return torch.cat([data['gnn0'].x for data in dataset], dim=0)


def replace_node_features(dataset, transformed_features):
    """ Replace the node features (x) in the original graphs with the transformed features. """
    start_idx = 0
    for data in dataset:
        end_idx = start_idx + data['gnn0'].x.size(0)
        data['gnn0'].x = transformed_features[start_idx:end_idx]
        start_idx = end_idx
    return dataset


def extract_node_features1(dataset):
    """ Extract the node features (x) from each graph in the dataset. """
    return torch.cat([data['gnn1'].x for data in dataset], dim=0)


def replace_node_features1(dataset, transformed_features):
    """ Replace the node features (x) in the original graphs with the transformed features. """
    start_idx = 0
    for data in dataset:
        end_idx = start_idx + data['gnn1'].x.size(0)
        data['gnn1'].x = transformed_features[start_idx:end_idx]
        start_idx = end_idx
    return dataset

def extract_node_features2(dataset):
    """ Extract the node features (x) from each graph in the dataset. """
    return torch.cat([data['gnn2'].x for data in dataset], dim=0)


def replace_node_features2(dataset, transformed_features):
    """ Replace the node features (x) in the original graphs with the transformed features. """
    start_idx = 0
    for data in dataset:
        end_idx = start_idx + data['gnn2'].x.size(0)
        data['gnn2'].x = transformed_features[start_idx:end_idx]
        start_idx = end_idx
    return dataset

def transform_node_features(train_dataset, val_dataset, test_dataset):
    # Convert PyTorch datasets to lists for easier manipulation
    train_list = [train_dataset[i] for i in range(len(train_dataset))]
    val_list = [val_dataset[i] for i in range(len(val_dataset))]
    test_list = [test_dataset[i] for i in range(len(test_dataset))]

    # Convert PyTorch datasets to lists for easier manipulation
    # train_list = [train_dataset[i][0] for i in range(len(train_dataset))]  # Unpack the data part
    # val_list = [val_dataset[i][0] for i in range(len(val_dataset))]
    # test_list = [test_dataset[i][0] for i in range(len(test_dataset))]

    # Convert PyTorch datasets to lists for easier manipulation
    # train_list = [train_dataset[i][0] for i in range(len(train_dataset))]  # Unpack the data part
    # val_list = [val_dataset[i][0] for i in range(len(val_dataset))]
    # test_list = [test_dataset[i][0] for i in range(len(test_dataset))]

    # Extract node features from each dataset
    X_train = extract_node_features(train_list)
    X_val = extract_node_features(val_list)
    X_test = extract_node_features(test_list)

    # Convert tensors to numpy for scaling
    X_train_np = X_train.numpy()
    X_val_np = X_val.numpy()
    X_test_np = X_test.numpy()

    # Initialize scalers
    scaler_min_max = MinMaxScaler()
    scaler_standard = StandardScaler()

    # Fit and transform training data
    X_train_np = scaler_min_max.fit_transform(X_train_np)
    X_train_np = scaler_standard.fit_transform(X_train_np)

    # Transform validation and test data using the fitted scalers
    X_val_np = scaler_min_max.transform(X_val_np)
    X_val_np = scaler_standard.transform(X_val_np)
    X_test_np = scaler_min_max.transform(X_test_np)
    X_test_np = scaler_standard.transform(X_test_np)

    # Convert numpy arrays back to tensors
    X_train_torch = torch.tensor(X_train_np, dtype=torch.float32)
    X_val_torch = torch.tensor(X_val_np, dtype=torch.float32)
    X_test_torch = torch.tensor(X_test_np, dtype=torch.float32)

    # Replace the original node features with transformed features
    train_dataset = replace_node_features(train_list, X_train_torch)
    val_dataset = replace_node_features(val_list, X_val_torch)
    test_dataset = replace_node_features(test_list, X_test_torch)

    return train_dataset, val_dataset, test_dataset


def transform_node_features1(train_dataset, val_dataset, test_dataset):
    # Convert PyTorch datasets to lists for easier manipulation
    train_list = [train_dataset[i] for i in range(len(train_dataset))]
    val_list = [val_dataset[i] for i in range(len(val_dataset))]
    test_list = [test_dataset[i] for i in range(len(test_dataset))]

    # Convert PyTorch datasets to lists for easier manipulation
    # train_list = [train_dataset[i][0] for i in range(len(train_dataset))]  # Unpack the data part
    # val_list = [val_dataset[i][0] for i in range(len(val_dataset))]
    # test_list = [test_dataset[i][0] for i in range(len(test_dataset))]
    # Extract node features from each dataset
    X_train = extract_node_features1(train_list)
    X_val = extract_node_features1(val_list)
    X_test = extract_node_features1(test_list)

    # Convert tensors to numpy for scaling
    X_train_np = X_train.numpy()
    X_val_np = X_val.numpy()
    X_test_np = X_test.numpy()

    # Initialize scalers
    scaler_min_max = MinMaxScaler()
    scaler_standard = StandardScaler()

    # Fit and transform training data
    X_train_np = scaler_min_max.fit_transform(X_train_np)
    X_train_np = scaler_standard.fit_transform(X_train_np)

    # Transform validation and test data using the fitted scalers
    X_val_np = scaler_min_max.transform(X_val_np)
    X_val_np = scaler_standard.transform(X_val_np)
    X_test_np = scaler_min_max.transform(X_test_np)
    X_test_np = scaler_standard.transform(X_test_np)

    # Convert numpy arrays back to tensors
    X_train_torch = torch.tensor(X_train_np, dtype=torch.float32)
    X_val_torch = torch.tensor(X_val_np, dtype=torch.float32)
    X_test_torch = torch.tensor(X_test_np, dtype=torch.float32)

    # Replace the original node features with transformed features
    train_dataset = replace_node_features1(train_list, X_train_torch)
    val_dataset = replace_node_features1(val_list, X_val_torch)
    test_dataset = replace_node_features1(test_list, X_test_torch)

    return train_dataset, val_dataset, test_dataset

def transform_node_features2(train_dataset, val_dataset, test_dataset):
    # Convert PyTorch datasets to lists for easier manipulation
    train_list = [train_dataset[i] for i in range(len(train_dataset))]
    val_list = [val_dataset[i] for i in range(len(val_dataset))]
    test_list = [test_dataset[i] for i in range(len(test_dataset))]

    # Convert PyTorch datasets to lists for easier manipulation
    # train_list = [train_dataset[i][0] for i in range(len(train_dataset))]  # Unpack the data part
    # val_list = [val_dataset[i][0] for i in range(len(val_dataset))]
    # test_list = [test_dataset[i][0] for i in range(len(test_dataset))]
    # Extract node features from each dataset
    X_train = extract_node_features2(train_list)
    X_val = extract_node_features2(val_list)
    X_test = extract_node_features2(test_list)

    # Convert tensors to numpy for scaling
    X_train_np = X_train.numpy()
    X_val_np = X_val.numpy()
    X_test_np = X_test.numpy()

    # Initialize scalers
    scaler_min_max = MinMaxScaler()
    scaler_standard = StandardScaler()

    # Fit and transform training data
    X_train_np = scaler_min_max.fit_transform(X_train_np)
    X_train_np = scaler_standard.fit_transform(X_train_np)

    # Transform validation and test data using the fitted scalers
    X_val_np = scaler_min_max.transform(X_val_np)
    X_val_np = scaler_standard.transform(X_val_np)
    X_test_np = scaler_min_max.transform(X_test_np)
    X_test_np = scaler_standard.transform(X_test_np)

    # Convert numpy arrays back to tensors
    X_train_torch = torch.tensor(X_train_np, dtype=torch.float32)
    X_val_torch = torch.tensor(X_val_np, dtype=torch.float32)
    X_test_torch = torch.tensor(X_test_np, dtype=torch.float32)

    # Replace the original node features with transformed features
    train_dataset = replace_node_features2(train_list, X_train_torch)
    val_dataset = replace_node_features2(val_list, X_val_torch)
    test_dataset = replace_node_features2(test_list, X_test_torch)

    return train_dataset, val_dataset, test_dataset


def verify_dataset_content(data_sample):
    # Check and plot image data if present
    if 'cnn' in data_sample:
        # Assume 'cnn' contains the image data as a torch Tensor in CHW format
        image_data = data_sample['cnn']
        if image_data.shape[0] == 3:  # RGB image
            # Correct permutation from CHW (Channels, Height, Width) to HWC (Height, Width, Channels)
            image_data = image_data.permute(1, 2, 0)
        elif image_data.shape[0] == 1:  # Grayscale image
            # Remove channel dimension for grayscale image
            image_data = image_data.squeeze(0)

        # Convert tensor to numpy array if not already done
        if not isinstance(image_data, np.ndarray):
            image_data = image_data.numpy()

        plt.imshow(image_data)
        plt.title("Image Data")
        plt.colorbar()
        plt.show()

    # Check and plot graph data if present
    if 'gnn' in data_sample:
        for i, graph in enumerate(data_sample['gnn']):
            G = to_networkx(graph, to_undirected=True)
            plt.figure(i + 1)
            nx.draw(G, with_labels=True, node_color='skyblue', node_size=700, edge_color='k')
            plt.title(f"Graph Data {i + 1}")
            plt.show()

            # Print graph contents
            print(f"Graph {i + 1} Details:")
            print("Nodes:", G.nodes(data=True))
            print("Edges:", G.edges(data=True))
            if 'x' in graph:
                print("Node Features:", graph.x)
            if 'edge_index' in graph:
                print("Edge Indices:", graph.edge_index)
            if 'edge_attr' in graph:
                print("Edge Attributes:", graph.edge_attr)
            if 'y' in graph:
                print("Graph Label:", graph.y)

    # Print global data if present
    if 'global' in data_sample:
        print("Global Data:", data_sample['global'])

    # Print label if present
    if 'label' in data_sample:
        print("Label:", data_sample['label'])


def print_graph_attributes(g):
    # Check and print node attributes
    print("Node Attributes:")
    for node, attrs in g.nodes(data=True):
        print(f"Node {node}:")
        for attr, value in attrs.items():
            print(f"  {attr}: {value}")

    # Check and print edge attributes
    print("\nEdge Attributes:")
    for u, v, attrs in g.edges(data=True):
        print(f"Edge ({u}, {v}):")
        for attr, value in attrs.items():
            print(f"  {attr}: {value}")