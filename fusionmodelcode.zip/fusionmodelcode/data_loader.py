import numpy as np
import torch
from matplotlib import pyplot as plt
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from torch_geometric.data import Batch
import networkx as nx
from torch_geometric.utils import to_networkx


def collate_data(batch):
    """
    Custom collate function to handle multiple graph types and global features.
    Each item in the batch can contain multiple graph types and feature sets.
    """
    batched_data = {}
    data_batch, indices = zip(*batch)  # Unzip the batch into data and indices
    # print(data_batch[0])
    # Example keys: 'gnn_nx_list', 'gnn_dual_graph_nx_list', 'global_features'
    keys = data_batch[0].keys()  # Assuming all items have the same structure
    # print(keys)
    # exit()
    for key in keys:
        if 'gnn0' in key:  # Graph data identified by 'gnn' prefix in key
            graph_data_list0 = [item[key] for item in data_batch]
            batched_data[key] = Batch.from_data_list(graph_data_list0)
        elif 'gnn1' in key:  # Graph data identified by 'gnn' prefix in key
            graph_data_list1 = [item[key] for item in data_batch]
            batched_data[key] = Batch.from_data_list(graph_data_list1)
        elif 'gnn2' in key:  # Graph data identified by 'gnn' prefix in key
            graph_data_list2 = [item[key] for item in data_batch]
            batched_data[key] = Batch.from_data_list(graph_data_list2)
        elif 'global' in key:  # Global features identified by 'global' prefix in key
            features_list = [item[key] for item in data_batch]
            batched_data[key] = torch.stack(features_list)
        elif 'global0' in key:  # Global features identified by 'global' prefix in key
            features_list = [item[key] for item in data_batch]
            batched_data[key] = torch.stack(features_list)
        elif 'cnn' in key:  # Image data identified by 'cnn' prefix in key
            images = torch.stack([item[key] for item in data_batch])
            batched_data[key] = images
        elif 'label' in key:  # Assuming 'label' key holds the labels
            labels = torch.tensor([item[key] for item in data_batch], dtype=torch.long)
            batched_data['label'] = labels

    return batched_data, indices  # Return both batched data and indices

def collate_data_with_index(batch):
    batched_data, indices = zip(*batch)
    return collate_data(batched_data), indices  # Assuming collate_data is your existing function


